#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
 
 char nome;
 int i;
 float soma_lucro=0,venda=0,valor=0;
 float soma_valor=0,lucro=0,perce_venda=0;
 float 
 
printf("\nDigite a Quantidade de mercadar\n")

for(i=1;i<=num;i++){

printf("\nNOME:\n");
 scanf("%s",&nome);

system("cls");

do{
system("cls");
printf("\nVALOR:\n");
 scanf("%f",&valor);
}while(valor<0)

system("cls");

do{
system("cls");
printf("\nPreco de venda:\n");
 scanf("%f",&venda);
}while(venda<0);

lucro = venda - valor;

soma_valor+=valor;
soma_lucro+=lucro;

perce_lucro = (soma_lucro*100)/soma_valor;

if(perce_lucro<10){

 for()
}




}





  

	system("pause");
	return 0;
}